<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('associate_country', function (Blueprint $table) {
            //
            $table->unsignedBigInteger('organization_id')->after('status')->nullable();
            $table->foreign('organization_id')->references('id')->on('tenant_list');
        });

        Schema::table('management', function (Blueprint $table) {
            //
            $table->unsignedBigInteger('organization_id')->after('status')->nullable();
            $table->foreign('organization_id')->references('id')->on('tenant_list');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('associate_country', function (Blueprint $table) {
            //
            $table->dropColumn('organization_id');
        });

        Schema::table('management', function (Blueprint $table) {
            //
            $table->dropColumn('organization_id');
        });
    }
};
