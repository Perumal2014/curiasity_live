@extends('backend.master')

@push('styles')
<style>
    .table-wrapper {
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 3px 10px rgba(0,0,0,0.1);
    }
    .primary-btn {
        border-radius: 6px;
        padding: 6px 12px;
        font-size: 14px;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .progress {
        height: 15px;
        border-radius: 8px;
        background-color: #e9ecef;
    }
    .progress-bar {
        background-color: #9734f2;
    }
    .badge-success {
        background: green;
        color: white;
        padding: 4px 8px;
        border-radius: 5px;
        font-size: 12px;
    }
    .badge-warning {
        background: orange;
        color: white;
        padding: 4px 8px;
        border-radius: 5px;
        font-size: 12px;
    }
    .badge-danger {
        background: red;
        color: white;
        padding: 4px 8px;
        border-radius: 5px;
        font-size: 12px;
    }
    .top-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    .top-controls .search-input {
        max-width: 300px;
    }
</style>
@endpush

@section('mainContent')
<section class="admin-visitor-area up_st_admin_visitor">
    <div class="container-fluid p-0">
        <div class="table-wrapper">
            <div class="top-controls">
                <h4>Course Enrollment Report</h4>
                 <div>
                   
                    <a href="{{ route('course.enrollment.export', request()->all()) }}" title="Excel">
                        <button type="button" class="btn btn-primary ">
                            <i class="fas fa-file-excel"></i>
                        </button>
                    </a>
                </div>
                
            </div>




            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Enrollment ID</th>
                            <th>Selection Criteria</th>
                            <th>Module</th>
                            <th>Company</th>
                            <th>College</th>
                            <th>Version</th>
                            <th>Language</th>
                            <th>Enrolled (UTC)</th>
                            <th>Started (UTC)</th>
                            <th>Completed (UTC)</th>
                            <th>Status</th>
                            <th>Progress</th>
                            <th>Time Spent (min)</th>
                            <th>Grade</th>
                            <th>Score</th>
                            <th>Total Mark</th>
                            <th>Attempts</th>
                            <th>Location</th>
                            <th>Profile</th>
                            <th>Duration (min)</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($reportData as $index => $row)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $row['name'] }}</td>
                                <td>{{ $row['email'] }}</td>
                                <td>{{ $row['course_title'] }}</td>
                                <td>{{ $row['unique_id'] }}</td>
                                <td>{{ $row['selection_criteria'] }}</td>
                                <td>{{ $row['module'] }}</td>
                                <td>{{ $row['company_name'] }}</td>
                                <td>{{ $row['college_name'] }}</td>
                                <td>{{ $row['version'] }}</td>
                                <td>{{ $row['language'] }}</td>
                                <td>{{ $row['enrollment_date'] }}</td>
                                <td>{{ $row['started_date'] }}</td>
                                <td>{{ $row['completion_date'] }}</td>
                                <td>
                                    @if($row['status'] == 'Completed')
                                        <span class="badge-success">{{ $row['status'] }}</span>
                                    @elseif($row['status'] == 'In Progress')
                                        <span class="badge-warning">{{ $row['status'] }}</span>
                                    @else
                                        <span class="badge-danger">{{ $row['status'] }}</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="progress" style="height: 15px;">
                                        <div class="progress-bar" role="progressbar" style="width: {{ $row['progress_percent'] }}%;" aria-valuenow="{{ (int)$row['progress_percent'] }}" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <small>{{ $row['progress_percent'] }}%</small>
                                </td>
                                <td>{{ $row['time_spent_minutes'] }}</td>
                                <td>{{ $row['grade'] }}</td>
                                <td>{{ $row['assessment_score'] }}</td>
                                <td>{{ $row['assessment_total_mark'] }}</td>
                                <td>{{ $row['attempts_taken'] }}</td>
                                <td>{{ $row['location'] }}</td>
                                <td>{{ $row['profile'] }}</td>
                                <td>{{ $row['training_duration_minutes'] }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="24" class="text-center">No enrollments found.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection
