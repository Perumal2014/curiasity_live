<?php

return [
    'name' => 'CourseSetting'
];
