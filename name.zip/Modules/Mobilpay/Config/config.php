<?php

return [
    'name' => 'Mobilpay'
];
