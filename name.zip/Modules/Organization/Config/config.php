<?php

return [
    'name' => 'Organization'
];
