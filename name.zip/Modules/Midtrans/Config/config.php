<?php

return [
    'name' => 'Midtrans'
];
